'use strict';
const crypto = require('crypto');
const https = require('https');

// Penyimpanan in-memory likes per stock: { [symbol]: Set(hashedIPs) }
const stockLikes = {};

function anonymizeIP(ip) {
  return crypto.createHash('sha256').update(ip || '').digest('hex');
}

function fetchStockData(symbol) {
  const url = `https://stock-price-checker-proxy.freecodecamp.rocks/v1/stock/${symbol}/quote`;
  if (typeof fetch === 'function') {
    return fetch(url).then(res => res.json());
  }
  return new Promise((resolve, reject) => {
    https.get(url, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          resolve(JSON.parse(data));
        } catch (e) {
          reject(e);
        }
      });
    }).on('error', reject);
  });
}

async function getStock(stock, like, ip) {
  const symbol = String(stock).toUpperCase();
  const data = await fetchStockData(symbol);

  if (!stockLikes[symbol]) {
    stockLikes[symbol] = new Set();
  }

  if (like === 'true' || like === true) {
    const hashedIP = anonymizeIP(ip);
    stockLikes[symbol].add(hashedIP);
  }

  return {
    stock: symbol,
    price: typeof data.latestPrice === 'number' ? data.latestPrice : 0,
    likes: stockLikes[symbol].size
  };
}

module.exports = function (app) {
  app.route('/api/stock-prices')
    .get(async function (req, res) {
      const { stock, like } = req.query;
      const ip = req.ip || req.headers['x-forwarded-for'] || req.socket.remoteAddress;

      try {
        if (Array.isArray(stock)) {
          const stock1 = await getStock(stock[0], like, ip);
          const stock2 = await getStock(stock[1], like, ip);

          return res.json({
            stockData: [
              {
                stock: stock1.stock,
                price: stock1.price,
                rel_likes: stock1.likes - stock2.likes
              },
              {
                stock: stock2.stock,
                price: stock2.price,
                rel_likes: stock2.likes - stock1.likes
              }
            ]
          });
        }

        const stockData = await getStock(stock, like, ip);
        return res.json({ stockData });
      } catch (err) {
        return res.json({ error: 'external source error' });
      }
    });
};